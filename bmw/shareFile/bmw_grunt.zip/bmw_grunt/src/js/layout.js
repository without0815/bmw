(function(window){

	function fn_test (argument) {
		// body...
		this.name='';
		this.age='';
	}

	fn_test.class_name.prototype.method_name = function(first_argument) {
		// body...
		var str="";
		var bb="123";
	};
})(window);