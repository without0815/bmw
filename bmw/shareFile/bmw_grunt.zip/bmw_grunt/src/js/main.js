

var win_fn=function(obj){
    this.pro='22222';
    this.popBox=function(){
        
    };
};